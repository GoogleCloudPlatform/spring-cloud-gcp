source /opt/concourse-java.sh
export TERM=dumb
setup_symlinks
cleanup_maven_repo "io.spring.gradle"
