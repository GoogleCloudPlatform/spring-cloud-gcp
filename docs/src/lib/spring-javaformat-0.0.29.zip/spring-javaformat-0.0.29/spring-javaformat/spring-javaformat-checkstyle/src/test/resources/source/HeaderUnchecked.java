/*
 * It really doesn't matter.
 */

/**
 * The header unchecked.
 *
 * @author Phillip Webb
 */
public class HeaderUnchecked {

}
